#!/bin/bash
make clean
rm -rf SimpleMapEditor.xcodeproj
rm -rf build
rm -rf SimpleMapEditor.app
rm Info.plist
rm moc_*.cpp
rm SimpleMapEditor.pro
rm ui_*.h
