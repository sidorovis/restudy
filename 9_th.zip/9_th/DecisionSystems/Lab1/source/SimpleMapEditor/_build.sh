./_clean.sh
./_generate.sh
xcodebuild -project SimpleMapEditor.xcodeproj

