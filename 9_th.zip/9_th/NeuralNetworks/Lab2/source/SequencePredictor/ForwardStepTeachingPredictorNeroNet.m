//
//  ForwardStepTeachingPredictorNeroNet.m
//  SequencePredictor
//
//  Created by Ivan Sidarau on 17.11.09.
//  Copyright 2009 Rilley_Elf Corp. All rights reserved.
//

#import "ForwardStepTeachingPredictorNeroNet.h"


@implementation ForwardStepTeachingPredictorNeroNet
-(void) teach
{
		[super teach];
}

@end
