//
//  NeuroNet.m
//  SequencePredictor
//
//  Created by Ivan Sidarau on 23.10.09.
//  Copyright 2009 Rilley_Elf Corp. All rights reserved.
//

#import "NeuroNet.h"


@implementation NeuroNet
-(id) init
{
	[super init];
	return self;
}
-(void) dealloc
{
	[super dealloc];
}

@end
