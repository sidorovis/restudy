//
//  main.m
//  NeuroArchivator
//
//  Created by Ivan Sidarau on 06.09.09.
//  Copyright rilley_elf corp 2009. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
