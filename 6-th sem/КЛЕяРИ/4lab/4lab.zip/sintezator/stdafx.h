// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//
#pragma warning( disable : 4786 )

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include <windows.h>
#include <mmsystem.h>
#include <tchar.h>

// TODO: reference additional headers your program requires here
