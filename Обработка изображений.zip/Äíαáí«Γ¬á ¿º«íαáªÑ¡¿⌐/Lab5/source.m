% 21
waver( 'flowers.tif' , 60 );
