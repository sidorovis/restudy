require 'test_helper'

class IntegerVariablesHelperTest < ActionView::TestCase
end
