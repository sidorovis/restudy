require 'test_helper'

class StringVariablesHelperTest < ActionView::TestCase
end
