require 'test_helper'

class ScenariosHelperTest < ActionView::TestCase
end
