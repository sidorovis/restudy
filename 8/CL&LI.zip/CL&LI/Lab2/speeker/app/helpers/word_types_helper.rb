module WordTypesHelper
end
