module RightsHelper
end
