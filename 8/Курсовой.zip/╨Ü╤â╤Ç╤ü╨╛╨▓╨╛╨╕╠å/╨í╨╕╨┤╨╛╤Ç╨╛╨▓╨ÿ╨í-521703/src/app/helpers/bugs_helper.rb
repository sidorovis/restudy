module BugsHelper
end
