require 'test_helper'

class BuildStatusesHelperTest < ActionView::TestCase
end
