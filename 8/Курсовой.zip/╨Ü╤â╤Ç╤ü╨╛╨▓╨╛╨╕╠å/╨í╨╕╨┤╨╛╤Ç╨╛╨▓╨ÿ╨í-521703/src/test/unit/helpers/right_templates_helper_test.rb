require 'test_helper'

class RightTemplatesHelperTest < ActionView::TestCase
end
