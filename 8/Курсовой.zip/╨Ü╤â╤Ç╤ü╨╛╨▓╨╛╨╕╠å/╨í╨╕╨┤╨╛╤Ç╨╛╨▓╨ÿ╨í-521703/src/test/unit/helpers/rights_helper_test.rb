require 'test_helper'

class RightsHelperTest < ActionView::TestCase
end
