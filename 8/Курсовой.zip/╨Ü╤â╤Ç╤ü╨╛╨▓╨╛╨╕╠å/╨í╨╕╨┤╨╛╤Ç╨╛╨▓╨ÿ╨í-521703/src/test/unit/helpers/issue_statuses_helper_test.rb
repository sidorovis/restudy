require 'test_helper'

class IssueStatusesHelperTest < ActionView::TestCase
end
