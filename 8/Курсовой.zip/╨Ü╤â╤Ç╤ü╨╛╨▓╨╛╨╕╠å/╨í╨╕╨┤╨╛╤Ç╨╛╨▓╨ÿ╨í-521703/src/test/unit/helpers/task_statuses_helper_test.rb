require 'test_helper'

class TaskStatusesHelperTest < ActionView::TestCase
end
