require 'test_helper'

class ProjectStatusesHelperTest < ActionView::TestCase
end
