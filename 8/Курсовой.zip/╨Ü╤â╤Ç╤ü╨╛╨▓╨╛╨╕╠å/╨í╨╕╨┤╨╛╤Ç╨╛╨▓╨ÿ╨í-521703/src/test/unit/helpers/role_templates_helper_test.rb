require 'test_helper'

class RoleTemplatesHelperTest < ActionView::TestCase
end
