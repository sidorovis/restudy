require 'test_helper'

class BugsHelperTest < ActionView::TestCase
end
