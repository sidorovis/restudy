require 'test_helper'

class TasksHelperTest < ActionView::TestCase
end
