require 'test_helper'

class ProjectsHelperTest < ActionView::TestCase
end
