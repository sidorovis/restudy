require 'test_helper'

class BugStatusesHelperTest < ActionView::TestCase
end
