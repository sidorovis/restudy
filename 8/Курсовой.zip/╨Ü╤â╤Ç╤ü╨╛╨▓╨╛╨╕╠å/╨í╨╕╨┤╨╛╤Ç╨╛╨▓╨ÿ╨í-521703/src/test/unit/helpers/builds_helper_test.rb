require 'test_helper'

class BuildsHelperTest < ActionView::TestCase
end
