#siteNotice {
	MARGIN-TOP: 5px; PADDING-LEFT: 4px; FONT-STYLE: italic; TEXT-ALIGN: center
}
#content {
	BACKGROUND: #f8fcff
}
#content DIV.thumb {
	BORDER-LEFT-COLOR: #f8fcff; BORDER-BOTTOM-COLOR: #f8fcff; BORDER-TOP-COLOR: #f8fcff; BORDER-RIGHT-COLOR: #f8fcff
}
.ns-0  #content {
	BACKGROUND: white
}
#mytabs LI {
	BACKGROUND: #f8fcff
}
.ns-0  #mytabs LI {
	BACKGROUND: white
}
#mytabs LI A {
	BACKGROUND-COLOR: #f8fcff
}
.ns-0  #mytabs LI A {
	BACKGROUND-COLOR: white
}
#p-cactions LI A {
	BACKGROUND-COLOR: #f8fcff
}
#p-cactions LI A:hover {
	BACKGROUND-COLOR: #f8fcff
}
#p-cactions LI.selected A {
	BACKGROUND-COLOR: #f8fcff
}
.ns-0  #p-cactions LI A {
	BACKGROUND-COLOR: #fbfbfb
}
.ns-0  #p-cactions LI.selected A {
	BACKGROUND-COLOR: white
}
.ns-0  #p-cactions LI A:hover {
	BACKGROUND-COLOR: white
}
.ns-0  #content DIV.thumb {
	BORDER-LEFT-COLOR: white; BORDER-BOTTOM-COLOR: white; BORDER-TOP-COLOR: white; BORDER-RIGHT-COLOR: white
}
#content BLOCKQUOTE {
	FONT-SIZE: 93.75%; MARGIN: 1em 1.6em
}
#content BLOCKQUOTE P {
	
}
#siteSub {
	DISPLAY: inline; FONT-WEIGHT: normal; FONT-SIZE: 92%
}
#bodyContent #siteSub A {
	PADDING-RIGHT: 0px; BACKGROUND-IMAGE: none; COLOR: #000; BACKGROUND-COLOR: transparent; TEXT-DECORATION: none
}
#ca-edit A {
	FONT-WEIGHT: bold! important
}
DIV.alreadyloggedin {
	FONT-WEIGHT: bold; COLOR: red
}

@media Print    
{
.editlink {
	DISPLAY: none
}
.noprint {
	DISPLAY: none
}
.metadata {
	DISPLAY: none
}
.dablink {
	DISPLAY: none
}
#content {
	BACKGROUND: #ffffff
}
    }
.diffchange {
	FONT-WEIGHT: bold
}
TD.diff-addedline {
	FONT-SIZE: 85%
}
TD.diff-deletedline {
	FONT-SIZE: 85%
}
TD.diff-context {
	FONT-SIZE: 85%
}
#pt-login {
	FONT-WEIGHT: bold; FONT-SIZE: 110%
}
FORM#userlogin {
	BORDER-RIGHT: #fc6 2px solid; PADDING-RIGHT: 1em; BORDER-TOP: #fc6 2px solid; PADDING-LEFT: 1em; FLOAT: left; PADDING-BOTTOM: 0.7em; BORDER-LEFT: #fc6 2px solid; COLOR: #000; MARGIN-RIGHT: 2em; PADDING-TOP: 1em; BORDER-BOTTOM: #fc6 2px solid; BACKGROUND-COLOR: #ffffe6
}
FORM#userlogin TABLE {
	FLOAT: left; COLOR: #000; BACKGROUND-COLOR: #ffffe6
}
P.error {
	FONT-WEIGHT: bold
}
.toccolours {
	BORDER-RIGHT: #aaaaaa 1px solid; PADDING-RIGHT: 5px; BORDER-TOP: #aaaaaa 1px solid; PADDING-LEFT: 5px; FONT-SIZE: 95%; PADDING-BOTTOM: 5px; BORDER-LEFT: #aaaaaa 1px solid; PADDING-TOP: 5px; BORDER-BOTTOM: #aaaaaa 1px solid; BACKGROUND-COLOR: #f9f9f9
}
#bodyContent .plainlinks A {
	PADDING-RIGHT: 0px! important; PADDING-LEFT: 0px! important; PADDING-BOTTOM: 0px! important; PADDING-TOP: 0px! important
}
#p-nav H5 {
	DISPLAY: none
}
.portlet A {
	TEXT-DECORATION: none
}
.portlet A:hover {
	TEXT-DECORATION: underline
}
#p-nav .pBody {
	PADDING-RIGHT: 0px
}
#p-nav A {
	DISPLAY: block; WIDTH: 100%
}
#editpage-specialchars A {
	TEXT-DECORATION: none
}
#editpage-specialchars A:hover {
	TEXT-DECORATION: underline
}
DIV.thumb DIV A IMG {
	BACKGROUND-COLOR: #ffffff
}
DIV.topicon {
	DISPLAY: block! important; Z-INDEX: 100; POSITION: absolute; TOP: 10px
}
.plainlinksneverexpand A.text:unknown {
	DISPLAY: none! important
}
DIV.Boxmerge {
	BORDER-RIGHT: #aaaaaa 1px solid; PADDING-RIGHT: 2px; BORDER-TOP: #aaaaaa 1px solid; PADDING-LEFT: 2px; FONT-SIZE: 95%; PADDING-BOTTOM: 2px; MARGIN: 0px; BORDER-LEFT: #aaaaaa 1px solid; PADDING-TOP: 2px; BORDER-BOTTOM: #aaaaaa 1px solid; BORDER-COLLAPSE: collapse; TEXT-ALIGN: center
}
DIV.NavFrame {
	BORDER-RIGHT: #aaaaaa 1px solid; PADDING-RIGHT: 2px; BORDER-TOP: #aaaaaa 1px solid; PADDING-LEFT: 2px; FONT-SIZE: 95%; PADDING-BOTTOM: 2px; MARGIN: 0px; BORDER-LEFT: #aaaaaa 1px solid; PADDING-TOP: 2px; BORDER-BOTTOM: #aaaaaa 1px solid; BORDER-COLLAPSE: collapse; TEXT-ALIGN: center
}
DIV.Boxmerge DIV.NavFrame {
	BORDER-TOP-STYLE: none; BORDER-RIGHT-STYLE: none; BORDER-LEFT-STYLE: none; BORDER-BOTTOM-STYLE: none
}
UNKNOWN {
	
}
DIV.NavPic {
	PADDING-RIGHT: 2px; PADDING-LEFT: 2px; FLOAT: left; PADDING-BOTTOM: 2px; MARGIN: 0px; PADDING-TOP: 2px; BACKGROUND-COLOR: #ffffff
}
DIV.NavFrame DIV.NavHead {
	FONT-WEIGHT: bold; FONT-SIZE: 100%; POSITION: relative; HEIGHT: 1.6em; BACKGROUND-COLOR: #efefef
}
DIV.NavFrame P {
	FONT-SIZE: 100%
}
DIV.NavFrame DIV.NavContent {
	FONT-SIZE: 100%
}
DIV.NavFrame DIV.NavContent P {
	FONT-SIZE: 100%
}
DIV.NavEnd {
	CLEAR: both; PADDING-RIGHT: 0px; PADDING-LEFT: 0px; PADDING-BOTTOM: 0px; MARGIN: 0px; LINE-HEIGHT: 1px; PADDING-TOP: 0px
}
A.NavToggle {
	FONT-WEIGHT: normal; FONT-SIZE: smaller; RIGHT: 3px; POSITION: absolute; TOP: 0px
}
#coordinates {
	PADDING-RIGHT: 0em; PADDING-LEFT: 0em; FONT-SIZE: 85%; Z-INDEX: 1; RIGHT: 30px; BACKGROUND: none transparent scroll repeat 0% 0%; FLOAT: right; PADDING-BOTTOM: 0em; MARGIN: 0em; TEXT-TRANSFORM: none; BORDER-TOP-STYLE: none; TEXT-INDENT: 0px; LINE-HEIGHT: 1.5em; PADDING-TOP: 0em; BORDER-RIGHT-STYLE: none; WHITE-SPACE: nowrap; BORDER-LEFT-STYLE: none; POSITION: absolute; TOP: 3.7em; TEXT-ALIGN: right; BORDER-BOTTOM-STYLE: none
}
.portlet LI {
	LIST-STYLE-IMAGE: url(http://upload.wikimedia.org/wikipedia/en/1/18/Monobook-bullet.png)
}
LI.FA {
	LIST-STYLE-IMAGE: url(http://upload.wikimedia.org/wikipedia/en/d/d4/Monobook-bullet-star.png)
}
