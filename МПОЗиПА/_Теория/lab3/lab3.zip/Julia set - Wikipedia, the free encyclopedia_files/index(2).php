A.new {
	COLOR: #cc2200
}
#quickbar A.new {
	COLOR: #cc2200
}
